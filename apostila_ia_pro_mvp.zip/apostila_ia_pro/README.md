# APOSTILA IA PRO — MVP funcional (versão inicial)

Aplicação web em Python, com interface responsiva. Não é apenas uma maquete: cadastro, autenticação, aprovação administrativa, contadores, biblioteca, exportação e pedidos são persistidos em SQLite. A produção real por IA exige chave da API OpenAI.

## Instalação

Python 3.10+ e estas dependências:

```bash
pip install python-docx python-pptx pypdf openpyxl reportlab
```

## Iniciar (Linux/macOS)

```bash
export ADMIN_EMAIL='seu-email@dominio.com'
export ADMIN_PASSWORD='escolha-uma-senha-forte-de-16-caracteres'
export OPENAI_API_KEY='sua-chave-da-api'  # necessário para gerar apostilas
python app.py
```

No PowerShell do Windows:

```powershell
$env:ADMIN_EMAIL='seu-email@dominio.com'
$env:ADMIN_PASSWORD='sua-senha-forte-com-16-caracteres'
$env:OPENAI_API_KEY='sua-chave-da-api'
python app.py
```

Acesse http://localhost:8080. O administrador inicial é criado automaticamente na primeira execução. A senha não fica armazenada em texto simples.

## Fluxo

1. Usuário solicita cadastro, aceita termos e aguarda liberação.
2. Administrador entra em **Administração**, vê contagem geral/individual de logins e aprova o usuário.
3. Usuário faz login e gera **uma apostila gratuita de até três páginas**.
4. Novos pedidos são criados no valor padrão de R$ 10,00; ficam pendentes até confirmação manual administrativa.
5. O administrador confirma que recebeu o pagamento **por um meio externo**, aprova o pedido e gera a apostila com IA.
6. O usuário baixa PDF e DOCX de sua biblioteca. O administrador edita preço, instruções, modelo e política de pesquisa.

## Limites honestos desta versão

- **Não há Pix automático, gateway, emissão de QR Code ou verificação bancária**. O painel apenas permite confirmar manualmente pagamentos recebidos fora da aplicação. Antes da operação comercial, integrar gateway com webhook assinado, reconciliação e estorno.
- **Pesquisa na internet** exige chave OpenAI, modelo compatível com `web_search_preview`, acesso à internet no servidor e cobrança da API; desative no editor se necessário. A IA não é infalível: revisar referências e precisão.
- **Arquivos suportados diretamente:** PDF textual, PPTX, DOCX, XLSX/XLSM, TXT, CSV, JSON, HTML, RTF (como texto). PDF digitalizado, imagens, vídeos, áudios, ZIP e formatos legados DOC/PPT/XLS ainda precisam de processadores/conversores adicionais. O sistema rejeita os não suportados, em vez de fingir leitura.
- Apostila gratuita: o PDF gerado é limitado a até 3 páginas por corte de conteúdo. O DOCX pode repaginar diferentemente dependendo do editor. Para garantia de equivalência entre formatos, implementar paginação DOCX com renderização específica.
- Apostila paga: não há teto comercial de páginas, mas respostas de IA têm limites técnicos; para dezenas ou centenas de páginas, implementar geração por capítulos, fila assíncrona e consolidação de volumes.
- **Antes de publicar na internet:** implementar HTTPS, proteção CSRF, rate-limiting, e-mail de recuperação/validação, logs de auditoria, políticas LGPD, backups, monitoramento, antivírus de uploads, filas de tarefas e tratamento de paralelismo. Esta versão é para piloto controlado, não para produção aberta.
- Senhas: PBKDF2-HMAC-SHA256 com sal, sessões aleatórias protegidas por cookie HttpOnly/SameSite. Defina `COOKIE_SECURE=1` em HTTPS.
- Os arquivos são processados em memória e texto extraído é armazenado no banco de dados; não compartilhe dados sensíveis sem política de privacidade e base legal adequada.

## Testar sem API

O cadastro, login, aprovação, estatísticas, configurações e pedidos funcionam sem a API. A geração dará erro explícito sem chave e não consumirá a gratuidade.
