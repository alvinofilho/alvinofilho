import os,re,json,sqlite3,secrets,hashlib,hmac,base64,io,datetime,urllib.request,urllib.error
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from urllib.parse import urlparse,parse_qs
from http.cookies import SimpleCookie
from pathlib import Path
from xml.sax.saxutils import escape
from docx import Document
from pptx import Presentation
from pypdf import PdfReader
from openpyxl import load_workbook
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,KeepTogether
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4

ROOT=Path(__file__).resolve().parent; DATA=Path(os.environ.get('APOSTILA_DATA_DIR',str(ROOT/'data'))); DATA.mkdir(exist_ok=True,parents=True)
DB=DATA/'app.sqlite3'; PORT=int(os.environ.get('PORT','8080'))
MIMES={'/':'text/html; charset=utf-8','/static/app.css':'text/css; charset=utf-8','/static/app.js':'application/javascript; charset=utf-8'}
DEFAULT_PROMPT=('Você é o APOSTILA IA PRO. Escreva em português brasileiro uma apostila acadêmica aprofundada e didática, com título, objetivos, sumário, capítulos numerados, exemplos, quadros, resumo, glossário, exercícios, gabarito comentado e referências verificáveis. Fundamente-se no material fornecido e em fontes externas confiáveis quando a pesquisa web estiver disponível. Não invente referências nem DOI. Diferencie fatos, interpretações e limitações. Responda em texto claro, com títulos e parágrafos. Se o pedido for gratuito, produza material compacto apropriado a no máximo três páginas A4; se for pago, aprofunde todos os tópicos relevantes.')
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def connect():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row;c.execute('PRAGMA foreign_keys=ON');return c
def init():
 with connect() as c:
  c.executescript('''CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,name TEXT NOT NULL,email TEXT NOT NULL UNIQUE,password_hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'user',status TEXT NOT NULL DEFAULT 'pending',free_used INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL,last_login TEXT);CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,user_id INTEGER NOT NULL,expires TEXT NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id));CREATE TABLE IF NOT EXISTS logins(id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL,at TEXT NOT NULL);CREATE TABLE IF NOT EXISTS books(id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL,title TEXT NOT NULL,kind TEXT NOT NULL,status TEXT NOT NULL,source_text TEXT,content TEXT,created_at TEXT NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id));CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL,book_id INTEGER NOT NULL,amount_cents INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'pending',created_at TEXT NOT NULL,confirmed_at TEXT,FOREIGN KEY(user_id) REFERENCES users(id));CREATE TABLE IF NOT EXISTS config(key TEXT PRIMARY KEY,value TEXT NOT NULL);''')
  for key,val in [('price_cents','1000'),('free_pages','3'),('prompt',DEFAULT_PROMPT),('model','gpt-4.1-mini'),('research','true')]:c.execute('INSERT OR IGNORE INTO config VALUES (?,?)',(key,val))
  if not c.execute("SELECT 1 FROM users WHERE role='admin'").fetchone():
   email=os.environ.get('ADMIN_EMAIL','admin@apostila.local').strip().lower();pwd=os.environ.get('ADMIN_PASSWORD','')
   if not pwd:raise RuntimeError('Configure ADMIN_PASSWORD no ambiente antes de iniciar o aplicativo (mínimo 12 caracteres).')
   if len(pwd)<12:raise RuntimeError('ADMIN_PASSWORD deve ter pelo menos 12 caracteres.')
   c.execute('INSERT INTO users(name,email,password_hash,role,status,created_at) VALUES (?,?,?,?,?,?)',('Administrador',email,hash_pw(pwd),'admin','active',now()))
def hash_pw(p):
 salt=secrets.token_bytes(16);v=hashlib.pbkdf2_hmac('sha256',p.encode(),salt,260000);return 'pbkdf2_sha256$260000$'+base64.b64encode(salt).decode()+'$'+base64.b64encode(v).decode()
def verify_pw(p,stored):
 try:
  method,iterations,salt,v=stored.split('$');return hmac.compare_digest(hashlib.pbkdf2_hmac('sha256',p.encode(),base64.b64decode(salt),int(iterations)),base64.b64decode(v))
 except: return False
def config(c):return {r['key']:r['value'] for r in c.execute('SELECT * FROM config')}
def extract(filename,data):
 suffix=Path(filename).suffix.lower();b=io.BytesIO(data)
 if suffix in ('.txt','.md','.csv','.json','.html','.htm','.rtf','.xml'):return data.decode('utf-8',errors='replace')[:120000]
 if suffix=='.pdf':return '\n'.join(page.extract_text() or '' for page in PdfReader(b).pages)[:120000]
 if suffix=='.docx':return '\n'.join(p.text for p in Document(b).paragraphs)[:120000]
 if suffix=='.pptx':return '\n'.join(sh.text for sl in Presentation(b).slides for sh in sl.shapes if sh.has_text_frame)[:120000]
 if suffix in ('.xlsx','.xlsm'):
  wb=load_workbook(b,read_only=True,data_only=True);return '\n'.join(' | '.join(str(v) for v in row if v is not None) for sh in wb for row in sh.iter_rows(values_only=True))[:120000]
 raise ValueError('Formato não processado diretamente. Converta para PDF, PPTX, DOCX, XLSX ou TXT. Áudio, vídeo e imagens precisam de integração multimodal.')
def ai_generate(topic,source,free,cfg):
 key=os.environ.get('OPENAI_API_KEY')
 if not key:raise ValueError('A geração por IA está indisponível: configure OPENAI_API_KEY no servidor. Nenhum crédito foi consumido.')
 limit='Limite o material gratuito a cerca de 1100 palavras, para caber em até 3 páginas.' if free else 'Produza uma apostila extensa, organizada em capítulos, com profundidade e todos os temas relevantes. Se necessário, enumere futuras continuações.'
 prompt=f'TEMA: {topic}\nREGRAS: {limit}\nMATERIAL ORIGINAL:\n{source[:65000] or "Nenhum arquivo enviado; use o tema informado."}'
 payload={'model':cfg['model'],'instructions':cfg['prompt'],'input':prompt,'max_output_tokens':12000}
 if cfg['research']=='true':payload['tools']=[{'type':'web_search_preview'}]
 req=urllib.request.Request('https://api.openai.com/v1/responses',data=json.dumps(payload).encode(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'},method='POST')
 try:
  with urllib.request.urlopen(req,timeout=180) as r:result=json.loads(r.read())
 except urllib.error.HTTPError as e:raise ValueError('A API de IA retornou erro: '+e.read().decode(errors='replace')[:300])
 except Exception as e:raise ValueError('Não foi possível acessar a API de IA: '+str(e))
 parts=[]
 for item in result.get('output',[]):
  for z in item.get('content',[]):
   if z.get('type')=='output_text':parts.append(z.get('text',''))
 out='\n\n'.join(parts).strip()
 if not out:raise ValueError('A API não retornou texto. Tente novamente.')
 return out

def blocks(content):
 lines=content.splitlines();result=[];buf=[]
 def flush():
  if buf:result.append(('p',' '.join(buf).strip()));buf.clear()
 for line in lines:
  s=line.strip()
  if not s:flush();continue
  if s.startswith('#') or (len(s)<95 and (s.isupper() or re.match(r'^\d+(?:\.\d+)*[.) -]',s))):flush();result.append(('h',s.strip('# ')))
  else:buf.append(s)
 flush();return result

def pdf_bytes(title,content,max_pages=None):
 styles=getSampleStyleSheet(); styles.add(ParagraphStyle(name='HeroCustom',fontName='Helvetica-Bold',fontSize=19,leading=24,textColor=colors.HexColor('#5231af'),spaceAfter=18,alignment=TA_CENTER));styles.add(ParagraphStyle(name='ChapterCustom',fontName='Helvetica-Bold',fontSize=12,leading=16,textColor=colors.HexColor('#263b88'),spaceBefore=13,spaceAfter=7));styles.add(ParagraphStyle(name='BodyCustom',fontName='Helvetica',fontSize=9.5,leading=14,spaceAfter=9))
 data=blocks(content);items=[Paragraph(escape(title),styles['HeroCustom']),Spacer(1,8)]
 def render(items):
  b=io.BytesIO();doc=SimpleDocTemplate(b,pagesize=A4,rightMargin=49,leftMargin=49,topMargin=45,bottomMargin=43)
  doc.build(list(items));return b.getvalue()
 for kind,txt in data:
  part=Paragraph(escape(txt),styles['ChapterCustom' if kind=='h' else 'BodyCustom']);items.append(part)
  if max_pages and len(items)%5==0:
   test=render(items[:]);
   if len(PdfReader(io.BytesIO(test)).pages)>max_pages:
    items.pop();break
 if max_pages:
  while len(items)>2 and len(PdfReader(io.BytesIO(render(items[:]))).pages)>max_pages:items.pop()
 return render(items)
def docx_bytes(title,content):
 doc=Document();doc.add_heading(title,0)
 for kind,txt in blocks(content):
  if kind=='h':doc.add_heading(txt,level=1)
  else:doc.add_paragraph(txt)
 b=io.BytesIO();doc.save(b);return b.getvalue()

class Handler(BaseHTTPRequestHandler):
 def send(self,status,obj,cookie=None):
  b=json.dumps(obj,ensure_ascii=False).encode();self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(b)));self.send_header('Cache-Control','no-store');
  if cookie:self.send_header('Set-Cookie',cookie)
  self.end_headers();self.wfile.write(b)
 def body(self):
  l=int(self.headers.get('Content-Length','0'))
  if l>18*1024*1024:raise ValueError('Limite da solicitação: 18 MB')
  return json.loads(self.rfile.read(l) or '{}')
 def auth(self,c):
  jar=SimpleCookie()
  try:jar.load(self.headers.get('Cookie',''));token=jar['session'].value
  except:return None
  return c.execute('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires>?',(hashlib.sha256(token.encode()).hexdigest(),now())).fetchone()
 def require(self,u,admin=False):
  if not u:raise PermissionError('Faça login primeiro.')
  if u['status']!='active':raise PermissionError('Seu cadastro ainda não foi liberado.')
  if admin and u['role']!='admin':raise PermissionError('Área restrita ao administrador.')
 def do_GET(self):
  path=urlparse(self.path).path
  if path in MIMES:
   p=ROOT/('templates/index.html' if path=='/' else path.lstrip('/'))
   if not p.is_file():self.send_error(404);return
   b=p.read_bytes();self.send_response(200);self.send_header('Content-Type',MIMES[path]);self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b);return
  try:
   with connect() as c:
    u=self.auth(c)
    if path=='/api/me':
     self.send(200,{'user':dict(u) if u else None,'pricing':{'price_cents':int(config(c)['price_cents']),'free_pages':int(config(c)['free_pages'])}});return
    self.require(u)
    if path=='/api/books':
     rows=c.execute('SELECT id,title,kind,status,created_at FROM books WHERE user_id=? ORDER BY id DESC',(u['id'],)).fetchall();self.send(200,{'books':[dict(x) for x in rows]});return
    if path=='/api/admin':
     self.require(u,True)
     users=[dict(r) for r in c.execute('SELECT id,name,email,role,status,free_used,created_at,last_login,(SELECT COUNT(*) FROM logins l WHERE l.user_id=u.id) AS accesses,(SELECT COUNT(*) FROM books b WHERE b.user_id=u.id AND b.status="ready") AS books FROM users u ORDER BY id DESC')]
     orders=[dict(r) for r in c.execute('SELECT o.*,u.email,b.title FROM orders o JOIN users u ON u.id=o.user_id JOIN books b ON b.id=o.book_id ORDER BY o.id DESC LIMIT 100')]
     stats={'users':len(users),'active':sum(x['status']=='active' for x in users),'accesses':c.execute('SELECT COUNT(*) FROM logins').fetchone()[0],'books':c.execute("SELECT COUNT(*) FROM books WHERE status='ready'").fetchone()[0],'revenue_cents':c.execute("SELECT COALESCE(SUM(amount_cents),0) FROM orders WHERE status='paid'").fetchone()[0]}
     self.send(200,{'users':users,'orders':orders,'stats':stats,'config':config(c)});return
    m=re.fullmatch(r'/api/books/(\d+)/(pdf|docx)',path)
    if m:
     book=c.execute('SELECT * FROM books WHERE id=?',(int(m[1]),)).fetchone()
     if not book or (book['user_id']!=u['id'] and u['role']!='admin') or book['status']!='ready':raise PermissionError('Apostila indisponível.')
     payload=pdf_bytes(book['title'],book['content'],int(config(c)['free_pages']) if book['kind']=='free' else None) if m[2]=='pdf' else docx_bytes(book['title'],book['content'])
     self.send_response(200);self.send_header('Content-Type','application/pdf' if m[2]=='pdf' else 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');self.send_header('Content-Disposition',f'attachment; filename="apostila_{book["id"]}.{m[2]}"');self.send_header('Content-Length',str(len(payload)));self.end_headers();self.wfile.write(payload);return
    self.send(404,{'error':'Rota não encontrada.'})
  except PermissionError as e:self.send(403,{'error':str(e)})
  except Exception as e:self.send(400,{'error':str(e)})
 def do_POST(self):
  path=urlparse(self.path).path
  try:
   d=self.body()
   with connect() as c:
    u=self.auth(c)
    if path=='/api/register':
     name=str(d.get('name','')).strip()[:100];email=str(d.get('email','')).strip().lower()[:200];pwd=str(d.get('password',''))
     if len(name)<2 or not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+',email) or len(pwd)<10 or not d.get('accepted'):raise ValueError('Informe nome, e-mail válido, senha com pelo menos 10 caracteres e aceite as condições.')
     try:c.execute('INSERT INTO users(name,email,password_hash,created_at) VALUES(?,?,?,?)',(name,email,hash_pw(pwd),now()))
     except sqlite3.IntegrityError:raise ValueError('E-mail já cadastrado.')
     self.send(201,{'message':'Cadastro enviado. Aguarde a liberação do administrador.'});return
    if path=='/api/login':
     email=str(d.get('email','')).lower().strip();row=c.execute('SELECT * FROM users WHERE email=?',(email,)).fetchone()
     if not row or not verify_pw(str(d.get('password','')),row['password_hash']):raise PermissionError('E-mail ou senha incorretos.')
     if row['status']!='active':raise PermissionError('Cadastro pendente ou bloqueado. Solicite liberação ao administrador.')
     token=secrets.token_urlsafe(36);expiration=(datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(days=7)).isoformat();c.execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),row['id'],expiration));c.execute('INSERT INTO logins(user_id,at) VALUES(?,?)',(row['id'],now()));c.execute('UPDATE users SET last_login=? WHERE id=?',(now(),row['id']))
     cookie='session='+token+'; HttpOnly; SameSite=Lax; Path=/; Max-Age=604800'+('; Secure' if os.environ.get('COOKIE_SECURE','')=='1' else '')
     self.send(200,{'message':'Login realizado.'},cookie);return
    if path=='/api/logout':
     jar=SimpleCookie();jar.load(self.headers.get('Cookie',''))
     if 'session' in jar:c.execute('DELETE FROM sessions WHERE token_hash=?',(hashlib.sha256(jar['session'].value.encode()).hexdigest(),))
     self.send(200,{'message':'Sessão encerrada.'},'session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');return
    self.require(u)
    if path=='/api/new-book':
     title=str(d.get('title','')).strip()[:160];topic=str(d.get('topic','')).strip()[:4000]
     if not title or not topic:raise ValueError('Informe título e tema.')
     files=d.get('files',[])
     if not isinstance(files,list) or len(files)>8:raise ValueError('Envie no máximo 8 arquivos por solicitação.')
     chunks=[]
     for f in files:
      raw=base64.b64decode(f.get('data',''),validate=True)
      if len(raw)>5*1024*1024:raise ValueError('Cada arquivo deve ter no máximo 5 MB.')
      chunks.append('ARQUIVO: '+str(f.get('name',''))+'\n'+extract(f.get('name',''),raw))
     source='\n\n'.join(chunks)[:110000];free=(u['free_used']==0 and not c.execute("SELECT 1 FROM books WHERE user_id=? AND kind='free' AND status IN ('processing','ready')",(u['id'],)).fetchone());kind='free' if free else 'paid';status='processing' if free else 'awaiting_payment'
     cur=c.execute('INSERT INTO books(user_id,title,kind,status,source_text,created_at) VALUES(?,?,?,?,?,?)',(u['id'],title,kind,status,('TEMA: '+topic+'\n'+source),now()));bid=cur.lastrowid
     if not free:
      amount=int(config(c)['price_cents']);c.execute('INSERT INTO orders(user_id,book_id,amount_cents,status,created_at) VALUES(?,?,?,?,?)',(u['id'],bid,amount,'pending',now()));self.send(201,{'book_id':bid,'paid':True,'message':f'Pedido criado. Pagamento de R$ {amount/100:.2f} pendente. O administrador deverá confirmar manualmente; nenhuma cobrança automática foi realizada.'});return
     c.commit()
     try:content=ai_generate(topic,source,True,config(c));pdf_bytes(title,content,int(config(c)['free_pages']))
     except Exception as e:c.execute('UPDATE books SET status="failed" WHERE id=?',(bid,));raise ValueError(str(e))
     c.execute('UPDATE books SET status="ready",content=? WHERE id=?',(content,bid));c.execute('UPDATE users SET free_used=1 WHERE id=?',(u['id'],));self.send(201,{'book_id':bid,'paid':False,'message':'Apostila gratuita criada com sucesso.'});return
    if path=='/api/admin/user':
     self.require(u,True);uid=int(d.get('id',0));status=d.get('status');
     if status not in ('active','pending','blocked'):raise ValueError('Status inválido.')
     target=c.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone()
     if not target or target['role']=='admin':raise ValueError('Não é permitido alterar contas administrativas aqui.')
     c.execute('UPDATE users SET status=? WHERE id=?',(status,uid));self.send(200,{'message':'Usuário atualizado.'});return
    if path=='/api/admin/config':
     self.require(u,True)
     updates={'price_cents':str(int(d.get('price_cents',1000))),'free_pages':str(int(d.get('free_pages',3))),'model':str(d.get('model','gpt-4.1-mini'))[:80],'prompt':str(d.get('prompt',DEFAULT_PROMPT))[:12000],'research':'true' if d.get('research') else 'false'}
     if not 100<=int(updates['price_cents'])<=100000 or not 1<=int(updates['free_pages'])<=3:raise ValueError('Preço deve estar entre R$1 e R$1000 e gratuidade até três páginas.')
     for k,v in updates.items():c.execute('UPDATE config SET value=? WHERE key=?',(v,k))
     self.send(200,{'message':'Configurações salvas.'});return
    if path=='/api/admin/order':
     self.require(u,True);oid=int(d.get('id',0));o=c.execute('SELECT * FROM orders WHERE id=?',(oid,)).fetchone()
     if not o or o['status']!='pending':raise ValueError('Pedido inexistente ou já resolvido.')
     decision=d.get('decision')
     if decision=='reject':c.execute('UPDATE orders SET status="rejected" WHERE id=?',(oid,));c.execute('UPDATE books SET status="cancelled" WHERE id=?',(o['book_id'],));self.send(200,{'message':'Pedido recusado.'});return
     if decision!='approve':raise ValueError('Ação inválida.')
     book=c.execute('SELECT * FROM books WHERE id=?',(o['book_id'],)).fetchone();source=book['source_text'] or '';topic=source.split('\n')[0].removeprefix('TEMA: ')
     c.commit()
     try:content=ai_generate(topic,source,False,config(c))
     except Exception as e:raise ValueError('Não foi possível gerar. Pedido permanece pendente. '+str(e))
     c.execute('UPDATE books SET status="ready",content=? WHERE id=?',(content,book['id']));c.execute('UPDATE orders SET status="paid",confirmed_at=? WHERE id=?',(now(),oid));self.send(200,{'message':'Pagamento marcado como confirmado e apostila gerada.'});return
    self.send(404,{'error':'Rota não encontrada.'})
  except PermissionError as e:self.send(403,{'error':str(e)})
  except Exception as e:self.send(400,{'error':str(e)})
 def log_message(self,*args):pass

if __name__=='__main__':
 init();print(f'APOSTILA IA PRO em http://localhost:{PORT}');ThreadingHTTPServer(('0.0.0.0',PORT),Handler).serve_forever()
